---
date: "2016-04-27T00:00:00Z"
external_link: http://example.org
image:
  caption: Photo by Toa Heftiba on Unsplash
  focal_point: Smart
summary: An example of linking directly to an external project website using `external_link`.
tags:
- Demo
title: External Project
---
