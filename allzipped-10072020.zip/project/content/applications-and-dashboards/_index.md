---
header:
  caption: ""
  image: ""
title: 'Applications & dashboards'
view: 4
---